﻿using System.Windows.Forms;

namespace MemoryGame
{
    public partial class Results : Form
    {
        public Results(string name, string tries, string time)
        {
            InitializeComponent();

            textBox1.Text = name;
            textBox3.Text = tries;
            textBox4.Text = time;
        }

        private void Results_Load(object sender, System.EventArgs e)
        {

        }

        private void label5_Click(object sender, System.EventArgs e)
        {

        }

        private void label6_Click(object sender, System.EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            GameMode gameMode = new GameMode(textBox1.Text);
            this.Hide();
            gameMode.ShowDialog();
            this.Close();
        }
    }
}

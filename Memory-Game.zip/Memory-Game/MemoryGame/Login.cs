﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MemoryGame
{
    public partial class Login : Form
    {
        
        Regex letters_numbers;


        public Login()
        {
            InitializeComponent();
          letters_numbers = new Regex(@"^[a-zA-Z0-9]+$");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (letters_numbers.IsMatch(textBox1.Text))
            {
                GameMode gameMode = new GameMode(textBox1.Text);
                this.Hide();
                gameMode.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username , please try another");
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

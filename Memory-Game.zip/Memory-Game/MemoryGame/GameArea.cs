﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MemoryGame
{
    public partial class GameArea : Form
    {
        Pictures picture; 


        string name;
        int tries = 0; 
        int time = 0; 
        bool click1, click2 = false;
        bool[] flag;
        string[] items;
        string[] defaults;
        PictureBox[] pictureBoxes;
        List<int> path = new List<int>();
        List<bool> finish = new List<bool>();
        List<string> newPaths = new List<string>();
        string mode;
        int amount;
        public GameArea(string mode, string name)
        {
            InitializeComponent();

            this.mode = mode;
            this.name = name;

            switch (mode)
            {
                case "Easy":
                    Height = 325;
                    amount = 8;
                    flag = new bool[8];
                    items = new string[8];
                    defaults = new string[8];
                    tries = 10;
                    break;
                case "Hard":
                    amount = 16;
                    flag = new bool[16];
                    items = new string[16];
                    defaults = new string[16];
                    tries = 15;
                    break;
            }

        }

        private void GameArea_Load(object sender, EventArgs e)
        {
            picture = new Pictures(); 

           
            for (int i = 0; i < amount; i++)
            {
                flag[i] = false;
            }

            
            for (int i = 1; i <= amount / 2; i++)
            {
                items[i - 1] = "images/img_" + i.ToString() + ".jpg";
                defaults[i - 1] = "images/img_" + i.ToString() + ".jpg";
            }

            for (int i = 1; i <= amount / 2; i++)
            {
                items[amount / 2 + i - 1] = "images/img_" + i.ToString() + ".jpg";
                defaults[amount / 2 + i - 1] = "images/img_" + i.ToString() + ".jpg";
            }
            switch (mode)
            {
                case "Easy":
                    label1.Text = "10";
                    pictureBoxes = new PictureBox[8] { pictureBox1, pictureBox2, pictureBox3, pictureBox4, pictureBox5,
                    pictureBox6, pictureBox7, pictureBox8};
                    break;
                case "Hard":
                    label1.Text = "15";
                    pictureBoxes = new PictureBox[16] { pictureBox1, pictureBox2, pictureBox3, pictureBox4, pictureBox5,
                     pictureBox6, pictureBox7, pictureBox8,pictureBox9, pictureBox10, pictureBox11, pictureBox12, pictureBox13,
                     pictureBox14, pictureBox15, pictureBox16};
                    break;
            }


            for (int j = 0; j < amount; j++)
            {
                flag[j] = false;
                pictureBoxes[j].Visible = true;
                pictureBoxes[j].ImageLocation = "images/back.jpg";
            }

            timer1.Enabled = false;

            resetToolStripMenuItem.Enabled = false;

           
            click1 = false;
            click2 = false;

            path.Clear();

            label3.Text = "0";
            time = 0;

            change(items); 

            
            for (int i = 0; i < amount; i++)
            {
                
                pictureBoxes[i].ImageLocation = pictureBoxes[i].Tag.ToString();
            }

            timer3.Enabled = true;  
        }



        void change(string[] array)
        {
            items = picture.shuffleArray(array, mode); 

            int index = 0;
            foreach (PictureBox pictureBox in pictureBoxes)
            {
               
                pictureBox.Tag = items[index];

                index++; 
            }
        }


        private void timer3_Tick(object sender, EventArgs e)
        {
           
            for (int j = 0; j < amount; j++)
            {
                flag[j] = false;
                pictureBoxes[j].ImageLocation = "images/back.jpg";
            }
            finish.Clear();
            resetToolStripMenuItem.Enabled = true;


            timer3.Enabled = false;
            timer1.Enabled = true;


            
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {

            timer1.Enabled = false;

            switch (mode)
            {
                case "Easy":
                    tries = 10;
                    label1.Text = "10";
                    break;
                case "Hard":
                    tries = 15;
                    label1.Text = "15";
                    break;
            }
            if (newPaths.Count <= amount)
            {
                for (int m = 0; m < amount; m++)
                {
                    items[m] = defaults[m];
                }
            }

            label3.Text = "0";
            for (int j = 0; j < amount; j++)
            {
                flag[j] = false;
                pictureBoxes[j].ImageLocation = "images/back.jpg";
            }


            timer1.Enabled = false;

            resetToolStripMenuItem.Enabled = false;

            click1 = false;
            click2 = false;

            path.Clear();
            time = 0;

            change(items);

            for (int i = 0; i < amount; i++)
            {
                
                pictureBoxes[i].ImageLocation = pictureBoxes[i].Tag.ToString();
            }

            timer3.Enabled = true; 

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time++;
            label3.Text = time.ToString();

            if (tries > 0)
            {
                if (finish.Count == amount)
                {
                    timer1.Enabled = false;

                    MessageBox.Show("Congratulations!");
                    Results results = new Results(name, tries.ToString(), time.ToString());
                    results.ShowDialog();

                    finish.Clear();
                    Close();

                }
            }
            else
            {

                timer1.Enabled = false;

                MessageBox.Show("You lose!");
                Results results = new Results(name, tries.ToString(), time.ToString());
                results.ShowDialog();

                finish.Clear();
                Close();
            }

        }

        void onClickOperation(int number)
        {
            if (timer1.Enabled == true && flag[number - 1] == false)
            {
                flag[number - 1] = true; 
                pictureBoxes[number - 1].ImageLocation = pictureBoxes[number - 1].Tag.ToString();
                path.Add(number - 1); 

               
                if (click1 == false)
                {
                    click1 = true;
                    click2 = false;
                }
                else if (click2 == false)
                {
                    click1 = true;
                    click2 = true;
                }

                if (click1 == true && click2 == true && path.Count == 2) 
                {
                    click1 = click2 = false;

                    if (pictureBoxes[path[0]].ImageLocation.Equals(pictureBoxes[path[1]].ImageLocation))
                    {
                        tries -= 1;
                        label1.Text = tries.ToString();

                        path.Clear();

                        finish.Add(true);
                        finish.Add(true);
                    }

                    else 

                    {
                        tries -= 1;
                        label1.Text = tries.ToString();

                        flag[path[0]] = false;
                        flag[path[1]] = false;

                        timer2.Enabled = true; 
                    }

                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            pictureBoxes[path[0]].ImageLocation = "images/back.jpg";
            pictureBoxes[path[1]].ImageLocation = "images/back.jpg";

            path.Clear();

            timer2.Enabled = false;
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(1);
        }

        private void pictureBox2_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(2);
        }

        private void pictureBox3_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(3);
        }

        private void pictureBox4_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(4);
        }

        private void pictureBox5_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(5);
        }

        private void pictureBox6_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(6);
        }

        private void pictureBox7_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(7);
        }

        private void pictureBox8_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(8);
        }

        private void pictureBox9_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(9);
        }

        private void pictureBox10_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(10);
        }

        private void pictureBox11_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(11);
        }

        private void pictureBox12_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(12);
        }

        private void pictureBox13_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(13);
        }

        private void pictureBox14_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(14);
        }

        private void pictureBox15_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(15);
        }

        private void pictureBox16_MouseClick(object sender, MouseEventArgs e)
        {
            onClickOperation(16);
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

    }
}

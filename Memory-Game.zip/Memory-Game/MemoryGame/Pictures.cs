﻿using System;

namespace MemoryGame
{
    class Pictures
    {
        Random random;

        public Pictures()
        {
            random = new Random();
        }

        internal string[] shuffleArray(string[] items,string mode)
        {
            
            int number; 
            string temp;
            int amount = 0;

            switch (mode)
            {
                case "Easy": 
                    amount = 7;
                    break;
                case "Hard": 
                    amount = 15;
                    break;
            }
            for (int y = 0; y < items.Length; y++)
            {
                number = random.Next(amount); 

                temp = items[y];
                items[y] = items[number];
                items[number] = temp;
            }

            return items;
        }
    }
}

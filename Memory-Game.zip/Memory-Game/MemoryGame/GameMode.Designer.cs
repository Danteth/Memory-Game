﻿namespace MemoryGame
{
    partial class GameMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Easy_Mode = new System.Windows.Forms.Button();
            this.Hard_Mode = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Easy_Mode
            // 
            this.Easy_Mode.Location = new System.Drawing.Point(79, 94);
            this.Easy_Mode.Name = "Easy_Mode";
            this.Easy_Mode.Size = new System.Drawing.Size(165, 66);
            this.Easy_Mode.TabIndex = 0;
            this.Easy_Mode.Tag = "Easy";
            this.Easy_Mode.Text = "Easy Mode";
            this.Easy_Mode.UseVisualStyleBackColor = true;
            this.Easy_Mode.Click += new System.EventHandler(this.button1_Click);
            // 
            // Hard_Mode
            // 
            this.Hard_Mode.Location = new System.Drawing.Point(79, 181);
            this.Hard_Mode.Name = "Hard_Mode";
            this.Hard_Mode.Size = new System.Drawing.Size(165, 66);
            this.Hard_Mode.TabIndex = 1;
            this.Hard_Mode.Tag = "Hard";
            this.Hard_Mode.Text = "Hard Mode";
            this.Hard_Mode.UseVisualStyleBackColor = true;
            this.Hard_Mode.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Viner Hand ITC", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(45, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(226, 44);
            this.label3.TabIndex = 12;
            this.label3.Text = "Choose the mode";
            // 
            // GameMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MemoryGame.Properties.Resources.Background_Image;
            this.ClientSize = new System.Drawing.Size(348, 333);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Hard_Mode);
            this.Controls.Add(this.Easy_Mode);
            this.Name = "GameMode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game mode";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Easy_Mode;
        private System.Windows.Forms.Button Hard_Mode;
        private System.Windows.Forms.Label label3;
    }
}
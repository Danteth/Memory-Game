﻿using System;
using System.Windows.Forms;

namespace MemoryGame
{
    public partial class GameMode : Form
    {
        string name;
        public GameMode(string name)
        {
            InitializeComponent();
            this.name = name; 
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        protected void button1_Click(object sender, EventArgs e)
        {
            Button q = (Button)sender;
           
            GameArea gameArea = new GameArea((string)q.Tag,name);
            this.Hide();
            gameArea.ShowDialog();
            this.Close();
            
        }
    }
}
